"""Privileged processing of archive directory change requests."""
from __future__ import annotations
import json
import os
import secrets
import stat
import tempfile
import time
from pathlib import Path
from . import storage_transaction
from .release import _snapshot
from .storage_system import StorageSystem,MediaSelection
from .upgrade_system import SystemAdapter

def status(adapter: SystemAdapter, state: str, message: str) -> None:
    if state not in ('applying','done','failed','recovery_required'):raise ValueError('invalid storage status')
    data=json.dumps({'state':state,'message':message,'updated':int(time.time())},ensure_ascii=False,separators=(',',':')).encode()
    temp=adapter.state/('.storage-status-'+secrets.token_hex(16))
    try:
        SystemAdapter._write_private(temp,data,mode=0o640)
        os.chown(temp,0,adapter.gid);os.chmod(temp,0o640);os.replace(temp,adapter.state/'storage-status.json')
        adapter._sync_parent(adapter.state/'storage-status.json')
    finally:temp.unlink(missing_ok=True)

def process(adapter: SystemAdapter, inbox: Path) -> bool:
    request=inbox/'storage-request.json'
    try:
        info=request.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_uid!=adapter.uid or info.st_nlink!=1 or info.st_size>4096:return False
    except FileNotFoundError:return False
    identity=(info.st_dev,info.st_ino);system=StorageSystem(adapter)
    try:
        with tempfile.TemporaryDirectory(prefix='.storage-input-',dir=adapter.state) as tmp:
            snapshot=Path(tmp)/'request.json';_snapshot(request,snapshot,4096)
            value=json.loads(snapshot.read_bytes())
            if (not isinstance(value,dict) or not {'archive','user_id'}<=set(value) or not set(value)<={'archive','user_id','exports','staging'} or not isinstance(value['archive'],str)
                or type(value['user_id']) is not int or value['user_id']<1):raise ValueError('invalid storage request')
            path=Path(value['archive'])
            if str(path)!=value['archive']:raise ValueError('non-canonical archive path')
            if 'exports' in value or 'staging' in value:
                def media_path(key,default):
                    val=value.get(key)
                    if val is None:return default
                    if not isinstance(val,str) or str(Path(val))!=val:raise ValueError('invalid media path')
                    return Path(val)
                from .config import load
                path=MediaSelection(path,media_path('exports',load(adapter.config_file).exports),media_path('staging',None))
            system.candidate(path)
            status(adapter,'applying','Zmienianie katalogu nagrań. Nagrywanie jest chwilowo wstrzymane.')
            storage_transaction.activate(adapter.state,path,system.operations())
        status(adapter,'done','Katalogi zmienione. Stare nagrania i eksporty pozostały na poprzednich ścieżkach.')
    except Exception:
        pending=storage_transaction._read(adapter.state) is not None
        status(adapter,'recovery_required' if pending else 'failed',
               'Zmiana katalogu przerwana. Wymagane odzyskiwanie.' if pending else 'Nie udało się zmienić katalogu. Sprawdź ścieżkę, właściciela i system plików.')
    finally:
        try:
            current=request.lstat()
            if (current.st_dev,current.st_ino)==identity:request.unlink()
        except FileNotFoundError:pass
    return True
