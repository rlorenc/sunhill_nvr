"""Unprivileged database update for a recording directory change."""
from __future__ import annotations
import argparse
import contextlib
import json
import hashlib
import shutil
import os
import re
import secrets
import stat
import time
from dataclasses import asdict
from pathlib import Path
from . import database,mount
from .config import load

def switch(db, archive: Path, staging: Path, *, inspect=mount.inspect, allow_rootfs=False) -> None:
    if not archive.is_absolute() or archive.is_symlink() or archive.resolve(strict=True)!=archive:
        raise ValueError('archive must be an existing canonical directory')
    actual=inspect(archive);stage=inspect(staging)
    mount.require_local(actual)
    if (actual.target=='/' and not allow_rootfs) or not mount.same(actual,stage):
        raise ValueError('archive and recording staging must be on the same data filesystem')
    root=os.open(archive,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    try:
        try:fd=os.open('.sunhill-volume-id',os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=root)
        except FileNotFoundError:
            token=secrets.token_hex(32)
            fd=os.open('.sunhill-volume-id',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=root)
            with os.fdopen(fd,'wb') as marker:
                marker.write(token.encode('ascii'));marker.flush();os.fsync(marker.fileno())
            os.fsync(root)
            fd=os.open('.sunhill-volume-id',os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=root)
        try:
            info=os.fstat(fd)
            if (not stat.S_ISREG(info.st_mode) or info.st_nlink!=1 or info.st_uid!=os.geteuid()
                or info.st_dev!=os.fstat(root).st_dev or info.st_size!=64):raise ValueError('invalid archive marker')
            token=os.read(fd,65).decode('ascii')
            if not re.fullmatch(r'[0-9a-f]{64}',token):raise ValueError('invalid archive marker')
        finally:os.close(fd)
        if not mount.same(actual,inspect(archive)):raise ValueError('archive mount changed')
        with db:
            db.executemany('INSERT INTO system_settings(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',
                           [('archive_mount',json.dumps(asdict(actual),separators=(',',':'))),('archive_marker',token)])
            db.execute('DELETE FROM recordings')
            db.execute('UPDATE camera_details SET last_file_at=NULL')
            db.execute("UPDATE export_jobs SET status='failed',error='Zmieniono katalog nagrań',worker=NULL,lease_until=NULL,updated=? WHERE status IN ('queued','running')",(int(time.time()),))
    finally:os.close(root)

def copy_exports(db,old: Path,new: Path) -> None:
    """Preserve completed downloads without deleting their old copies.

    All copies run as sunhill. Conflicts fail closed; retry accepts identical
    files from an earlier interrupted attempt, never overwrites existing ones.
    """
    from .files import open_export
    from .atomic_publish import publish_new_file
    def digest(fd):
        h=hashlib.sha256()
        with os.fdopen(os.dup(fd),'rb') as stream:
            stream.seek(0)
            for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
        return h.digest()
    for job_id,name in db.execute("SELECT id,result_name FROM export_jobs WHERE status='done' AND result_name IS NOT NULL"):
        if not re.fullmatch(r'export-'+str(job_id)+r'-[a-f0-9]{16}\.mp4',name):raise ValueError('invalid export name')
        fd,info=open_export(old,name)
        temp=new/('.migration-'+secrets.token_hex(16))
        try:
            try:existing,_=open_export(new,name)
            except FileNotFoundError:existing=None
            if existing is not None:
                try:
                    if digest(existing)!=digest(fd):raise ValueError('export destination contains a different file')
                finally:os.close(existing)
                continue
            with os.fdopen(os.dup(fd),'rb') as src,temp.open('xb') as dst:
                os.fchmod(dst.fileno(),0o600);shutil.copyfileobj(src,dst,1024*1024);dst.flush();os.fsync(dst.fileno())
            after=os.fstat(fd)
            if (info.st_size,info.st_mtime_ns,info.st_ino)!=(after.st_size,after.st_mtime_ns,after.st_ino):raise ValueError('export changed during copy')
            publish_new_file(temp,new/name)
        finally:os.close(fd);temp.unlink(missing_ok=True)
    with db:
        db.execute("UPDATE export_jobs SET status='failed',error='Zmieniono katalog eksportów',worker=NULL,lease_until=NULL,result_name=NULL,updated=? WHERE status='running'",(int(time.time()),))
        db.execute("UPDATE export_jobs SET result_name=NULL WHERE status='failed'")


def switch_media(db,cfg,archive: Path,staging: Path,exports: Path) -> None:
    # Run as the service account, not as root. Never follow a directory symlink.
    for path in (archive,exports,staging):
        if not path.is_absolute() or path.resolve(strict=False)!=path:raise ValueError('invalid media directory')
        if path==staging and not path.exists():path.mkdir(mode=0o750)
        info=path.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid!=os.geteuid() or info.st_mode&0o022:raise ValueError('invalid media directory ownership')
        mount.require_local(mount.inspect(path))
    if not mount.same(mount.inspect(archive),mount.inspect(staging)):raise ValueError('archive and staging filesystem mismatch')
    if exports!=cfg.exports:copy_exports(db,cfg.exports,exports)
    if archive!=cfg.archive:switch(db,archive,staging,allow_rootfs=True)


def main(argv=None) -> int:
    parser=argparse.ArgumentParser();parser.add_argument('--config',type=Path,required=True);parser.add_argument('archive',type=Path);parser.add_argument('--staging',type=Path);parser.add_argument('--exports',type=Path)
    args=parser.parse_args(argv);cfg=load(args.config)
    with contextlib.closing(database.open_db(cfg.database)) as db:
        if args.staging is not None or args.exports is not None:switch_media(db,cfg,args.archive,args.staging or cfg.staging,args.exports or cfg.exports)
        else:switch(db,args.archive,cfg.staging)
    return 0

if __name__=='__main__':raise SystemExit(main())
