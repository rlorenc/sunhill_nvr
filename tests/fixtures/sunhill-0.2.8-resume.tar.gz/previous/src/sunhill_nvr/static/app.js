const $ = (id) => document.getElementById(id);
let me = null;
let cameras = [];
let layouts = [];
let activeCamera = null;
let records = [];
let eventMarkers = [];
let recordPosition = 0;
let playbackGeneration = 0;
let archiveLoadGeneration = 0;
let loadedArchiveDate = null;
let calendarGeneration = 0;
let exportListGeneration = 0;
let exportListPending = false;
let exportListRefreshAgain = false;
let timelineRequestGeneration = 0;
let timelineSelection = null;
let timelineFormatter = null;
let timelineFormatterZone = null;
let cameraRefreshGeneration = 0;
let statusRefreshPending = false;
let adminRefreshGeneration = 0;
let exportViewGeneration = 0;
let exportTimer = null;
let exportSubmitting = false;
let protectionSubmitting = false;
let livePlayerLoading = false;
let livePlayerRetry = null;
let livePlayerAttempts = 0;
const livePreferences = new Map();
function selectedLiveAlias(camera, quality, enlarged){
  if(quality==='compatible')return '~'+camera.slug;
  if(quality==='sub'&&camera.sub_configured)return camera.slug+'_sub';
  if(quality==='auto'&&!enlarged&&camera.sub_configured)return camera.slug+'_sub';
  return camera.slug;
}
function closeLivePlayer(player){
  if(typeof player.ondisconnect==='function')player.ondisconnect();
}

function livePlayerReady(){return typeof customElements!=='undefined'&&Boolean(customElements.get('video-stream'));}
function ensureLivePlayer(){
  if(!me||typeof customElements==='undefined'||livePlayerReady()||livePlayerLoading||livePlayerRetry!==null)return;
  livePlayerLoading=true;
  const script=document.createElement('script');script.type='module';script.src='/live/player/'+(++livePlayerAttempts)+'/video-stream.js';
  const retry=()=>{
    livePlayerLoading=false;script.remove();
    if(!me||livePlayerReady())return;
    const delay=Math.min(60000,1000*2**Math.min(livePlayerAttempts-1,6));
    livePlayerRetry=setTimeout(()=>{livePlayerRetry=null;ensureLivePlayer();},delay);
  };
  script.onerror=retry;
  script.onload=()=>{
    if(!livePlayerReady()){retry();return;}
    livePlayerLoading=false;livePlayerAttempts=0;script.remove();
    // Create players only after their custom element has been registered.
    if(me&&!$('camera-view').hidden)renderCameras();
  };
  document.head.append(script);
}

function notify(message) { $('notice').textContent = message || ''; }
function cookie(name) {
  const item = document.cookie.split('; ').find((part) => part.startsWith(name + '='));
  return item ? decodeURIComponent(item.slice(name.length + 1)) : '';
}
async function api(url, method = 'GET', data = null) {
  const options = {method, credentials:'same-origin', headers:{}};
  if (method !== 'GET') options.headers['X-CSRF-Token'] = cookie('sunhill_csrf');
  if (data !== null) {options.headers['Content-Type']='application/json';options.body=JSON.stringify(data);}
  const response = await fetch(url, options);
  let value;try{value=await response.json();}catch{throw new Error(response.status===503?'Serwer jest chwilowo niedostępny.':'Nieprawidłowa odpowiedź serwera.');}
  if (!response.ok) {const error=new Error(value.error || 'Błąd żądania');error.status=response.status;throw error;}
  return value;
}
function element(tag, text, className) {
  const node=document.createElement(tag);if(text)node.textContent=text;if(className)node.className=className;return node;
}
function formData(form) { return Object.fromEntries(new FormData(form)); }
async function archivePages(url,key,stillCurrent=()=>true){
  const items=[];let cursor=null;const seen=new Set();
  do {
    if(!stillCurrent())return {[key]:[]};
    const page=await api(url+(cursor?'&cursor='+encodeURIComponent(cursor):''));
    if(!stillCurrent())return {[key]:[]};
    if(!Array.isArray(page[key]))throw new Error('Nieprawidłowa odpowiedź archiwum.');
    items.push(...page[key]);
    cursor=page.next_cursor||null;
    if(cursor&&(typeof cursor!=='string'||seen.has(cursor)||seen.size>=100))throw new Error('Nie można wczytać pełnej listy archiwum.');
    if(cursor)seen.add(cursor);
  } while(cursor);
  return {[key]:items};
}
function cameraHealthText(camera){
  if(!camera.enabled)return 'Kamera wyłączona';
  const recording={unknown:'brak danych',waiting:'oczekiwanie',recording:'nagrywa',stale:'brak nowych plików',clock_skew:'nieprawidłowy czas nagrań',offline:'niedostępny',disabled:'wyłączony'};
  const stream={unknown:'brak danych',available:'dostępny',unavailable:'niedostępny'};
  const paused={disk_low:'wstrzymany - mało miejsca',disk_unavailable:'wstrzymany - niedostępny dysk'};
  return `Obraz: ${camera.stream_gateway_failed?'bramka niedostępna':(stream[camera.stream_health]||'brak danych')} | Zapis: ${paused[camera.recording_pause_reason]||recording[camera.health]||'brak danych'}`;
}
function view(which) {
  const cameraWasHidden=$('camera-view').hidden;
  if(which!=='archive'&&!$('archive-view').hidden){playbackGeneration++;archiveLoadGeneration++;clearTimeout(previewTimer);$('timeline-preview').hidden=true;$('archive-player').pause();}
  if(which!=='sync')stopSync();$('camera-view').hidden=which!=='cameras';$('archive-view').hidden=which!=='archive';$('sync-view').hidden=which!=='sync';$('admin-view').hidden=which!=='admin';
  if(which==='cameras'&&cameraWasHidden)renderCameras();
  else if(which!=='cameras'){
    for(const player of $('cameras').querySelectorAll('video-stream'))closeLivePlayer(player);
    $('cameras').replaceChildren();
  }
}
async function refreshCameras() {
  const generation=++cameraRefreshGeneration,incoming=(await api('/api/cameras')).cameras;
  if(generation!==cameraRefreshGeneration)return;
  cameras=incoming;await refreshLayouts();if(generation===cameraRefreshGeneration)renderCameras();
}
async function refreshCameraStatus(){
  const generation=++cameraRefreshGeneration,incoming=(await api('/api/cameras')).cameras;
  if(generation!==cameraRefreshGeneration||$('camera-view').hidden)return;
  const shape=list=>JSON.stringify(list.map(c=>[c.id,c.name,c.slug,c.enabled,c.sub_configured,c.may_download]));
  const changed=shape(cameras)!==shape(incoming);cameras=incoming;
  if(changed){await refreshLayouts();if(generation===cameraRefreshGeneration&&!$('camera-view').hidden)renderCameras();return;}
  for(const card of $('cameras').querySelectorAll('.camera')){
    const camera=incoming.find(item=>String(item.id)===card.dataset.cameraId),label=card.querySelector('.health');
    if(camera&&label)label.textContent=cameraHealthText(camera);
  }
}
async function refreshLayouts(){
  layouts=(await api('/api/layouts')).layouts;const select=$('layout-select'),old=select.value;
  select.replaceChildren(new Option('Wszystkie kamery',''));for(const layout of layouts)select.add(new Option(layout.name,String(layout.id)));select.value=layouts.some(layout=>String(layout.id)===old)?old:'';
  const choices=$('layout-cameras');choices.replaceChildren();for(const camera of cameras){const label=element('label');const input=element('input');input.type='checkbox';input.value=String(camera.id);input.checked=true;label.append(input,document.createTextNode(camera.name));choices.append(label);}
}
function renderCameras() {
  const area=$('cameras');for(const player of area.querySelectorAll('video-stream'))closeLivePlayer(player);area.replaceChildren();
  if($('camera-view').hidden)return;
  ensureLivePlayer();
  const keys=new Set(cameras.filter(c=>c.enabled).map(c=>String(c.id)+':'+c.slug));
  for(const key of livePreferences.keys())if(!keys.has(key))livePreferences.delete(key);
  const layout=layouts.find(x=>String(x.id)===$('layout-select').value);const visible=layout?cameras.filter(c=>layout.cameras.includes(c.id)):cameras;
  for (const camera of visible) {
const card=element('article',null,'camera');card.dataset.cameraId=String(camera.id);const top=element('div',null,'camera-heading');
    top.append(element('strong',camera.name));top.append(element('span',cameraHealthText(camera),'health'));card.append(top);
    const key=String(camera.id)+':'+camera.slug,previous=livePreferences.get(key)||{quality:'auto',enlarged:false};
    let enlarged=Boolean(previous.enlarged&&camera.enabled),selected=previous.quality;
    if(selected==='sub'&&!camera.sub_configured)selected='auto';
    if(enlarged)card.classList.toggle('expanded');
    const remember=()=>livePreferences.set(key,{quality:selected,enlarged});
    function player(alias){const item=document.createElement('video-stream');item.mode='mse';item.media='video,audio';item.background=false;item.src=new URL('/live/api/ws?src='+encodeURIComponent(alias),location.origin);return item;}
    let video=null,currentAlias=null;
    if(camera.enabled){if(livePlayerReady()){currentAlias=selectedLiveAlias(camera,selected,enlarged);video=player(currentAlias);card.append(video);}else card.append(element('p','Oczekiwanie na usługę podglądu.','camera-actions'));}else card.append(element('p','Podgląd wyłączony','camera-actions'));
    const actions=element('div',null,'camera-actions');
    const quality=element('select');quality.setAttribute('aria-label','Jakość podglądu '+camera.name);quality.add(new Option('Jakość automatyczna','auto'));quality.add(new Option('Strumień główny','main'));if(camera.sub_configured)quality.add(new Option('Strumień pomocniczy','sub'));quality.add(new Option('Zgodność H.264 - większe obciążenie CPU','compatible'));quality.value=selected;quality.hidden=!camera.enabled;
    const sound=element('button','Włącz dźwięk');sound.type='button';sound.hidden=!camera.enabled;
    let audioGeneration=0;
    function audioLabel(audible){sound.textContent=audible?'Wycisz':'Włącz dźwięk';sound.setAttribute('aria-pressed',String(audible));sound.setAttribute('aria-label',sound.textContent+' kamery '+camera.name);}
    audioLabel(false);
    function observeAudio(owner){
      if(!owner)return;
      const sync=event=>{
        if(owner!==video||!owner.video||event.target!==owner.video)return;
        audioLabel(!owner.video.muted&&owner.video.volume!==0);
      };
      // Media events do not bubble, but the native video is a child of the
      // player. Capture browser/native control changes and reconnections.
      owner.addEventListener('volumechange',sync,true);
      owner.addEventListener('loadedmetadata',sync,true);
    }
    observeAudio(video);
    sound.addEventListener('click',async()=>{
      const owner=video,native=owner&&owner.video;if(!native){notify('Odtwarzacz nie jest jeszcze gotowy.');return;}
      const generation=++audioGeneration,desired=!(native.muted||native.volume===0);
      if(!desired&&native.volume===0)native.volume=1;
      native.muted=desired;audioLabel(!desired);
      try{if(!desired)await native.play();}catch{
        // An older rejected play() must not mute a newer user choice or player.
        if(generation!==audioGeneration||video!==owner)return;
        native.muted=true;audioLabel(false);notify('Przeglądarka nie zezwoliła na odtwarzanie dźwięku.');
      }
    });
    function replacePlayer(alias){if(!video)return;const replacement=player(alias);audioGeneration++;closeLivePlayer(video);video.replaceWith(replacement);video=replacement;currentAlias=alias;audioLabel(false);observeAudio(replacement);}
    function changeQuality(){selected=quality.value;remember();if(!video)return;const alias=selectedLiveAlias(camera,selected,enlarged);if(alias!==currentAlias)replacePlayer(alias);}
    quality.addEventListener('change',changeQuality);actions.append(quality,sound);
    const retry=element('button','Połącz ponownie');retry.type='button';retry.hidden=!camera.enabled;retry.addEventListener('click',()=>{if(video)replacePlayer(currentAlias);else{ensureLivePlayer();if(livePlayerReady())renderCameras();}});actions.append(retry);
    const expand=element('button',enlarged?'Zmniejsz':'Powiększ');expand.hidden=!camera.enabled;expand.addEventListener('click',()=>{enlarged=card.classList.toggle('expanded');expand.textContent=enlarged?'Zmniejsz':'Powiększ';remember();if(quality.value==='auto')changeQuality();});actions.append(expand);
    const button=element('button','Archiwum');
    button.addEventListener('click',()=>openArchive(camera));actions.append(button);card.append(actions);area.append(card);
  }
  if (!visible.length) area.append(element('p','Brak kamer w wybranym widoku.'));
}
async function openArchive(camera) {
  exportViewGeneration++;if(exportTimer!==null)clearInterval(exportTimer);exportTimer=null;exportSubmitting=false;protectionSubmitting=false;
  clearTimeout(previewTimer);$('timeline-preview').hidden=true;
  clearTimelineSelection();
  activeCamera=camera;resetArchiveContents();loadedArchiveDate=null;$('archive-title').textContent='Archiwum - '+camera.name;
  playbackGeneration++;$('archive-date').value=cameraDay();$('archive-timezone').textContent='Strefa czasowa kamer: '+me.timezone;$('archive-player').pause();$('archive-player').removeAttribute('src');
  $('archive-month').value=$('archive-date').value.slice(0,7);$('calendar-days').replaceChildren();$('recordings').replaceChildren();$('save-frame').hidden=!camera.may_download;$('export-panel').hidden=!camera.may_download;$('export-result').replaceChildren();view('archive');await Promise.all([loadArchive(),loadCalendar(),camera.may_download?refreshExports():Promise.resolve()]);
}
async function refreshExports(){
  if(exportListPending){exportListRefreshAgain=true;return;}
  exportListPending=true;
  const generation=++exportListGeneration;
  try{
    const result=await api('/api/export-jobs');
    if(generation!==exportListGeneration)return;
    const box=$('exports-list');box.replaceChildren();
    const labels={queued:'W kolejce',running:'Przetwarzanie',done:'Gotowe',failed:'Błąd'};
    for(const job of result.jobs){
      const row=element('div',null,'recording-row');
      const percent=job.status==='running'?' - '+Math.round(Math.max(0,Math.min(1,Number(job.progress)||0))*100)+'%':'';
      const created=new Intl.DateTimeFormat('pl-PL',{timeZone:me.timezone,dateStyle:'short',timeStyle:'medium'}).format(new Date(job.created*1000));
      row.append(element('span',`${job.camera} | ${created} | ${job.cancel_requested?'Anulowanie':job.cancelled?'Anulowano':labels[job.status]||job.status}${percent}`));
      if(job.download_ready){const link=element('a','Pobierz MP4');link.href=`/api/export-jobs/${job.id}/file`;row.append(link);}
      if(job.status==='failed'&&job.error)row.append(element('span',job.error));
      if((job.status==='queued'||job.status==='running')&&!job.cancel_requested){
        const cancel=element('button','Anuluj eksport');cancel.type='button';
        cancel.addEventListener('click',async()=>{if(!window.confirm('Anulować ten eksport?'))return;cancel.disabled=true;try{await api(`/api/export-jobs/${job.id}/cancel`,'POST',{});await refreshExports();}catch(error){cancel.disabled=false;notify(error.message);}});row.append(cancel);
      }
      if(job.status!=='running'){
        const remove=element('button',job.status==='queued'?'Usuń zadanie':'Usuń eksport');remove.type='button';
        remove.addEventListener('click',async()=>{if(!window.confirm('Usunąć zadanie i jego gotowy plik eksportu?'))return;remove.disabled=true;try{await api(`/api/export-jobs/${job.id}`,'DELETE');await refreshExports();}catch(error){remove.disabled=false;notify(error.message);}});row.append(remove);
      }
      box.append(row);
    }
    if(!result.jobs.length)box.append(element('p','Brak eksportów.'));
  }catch(error){notify(error.message);}
  finally{exportListPending=false;if(exportListRefreshAgain){exportListRefreshAgain=false;refreshExports();}}
}
$('exports-refresh').addEventListener('click',refreshExports);
setInterval(()=>{if(me&&!document.hidden)refreshExports();},5000);
async function loadCalendar(){
  const generation=++calendarGeneration,camera=activeCamera,month=$('archive-month').value;
  try{
    const result=await api(`/api/cameras/${camera.id}/calendar?month=${encodeURIComponent(month)}`);
    if(generation!==calendarGeneration||camera!==activeCamera||month!==$('archive-month').value)return;
    const box=$('calendar-days');box.replaceChildren();
    for(const day of result.days){const button=element('button',day);button.type='button';button.addEventListener('click',()=>{$('archive-date').value=day;loadArchive();});box.append(button);}
    if(!result.days.length)box.append(element('p','Brak nagrań w wybranym miesiącu.'));
  }catch(error){if(generation===calendarGeneration&&camera===activeCamera&&month===$('archive-month').value)notify(error.message);}
}
$('load-calendar').addEventListener('click',loadCalendar);
function resetArchiveContents(){
  records=[];eventMarkers=[];recordPosition=0;
  $('recordings').replaceChildren();$('timeline-track').replaceChildren();$('events').replaceChildren();
  $('timeline-position').value='0';$('timeline-time').textContent='00:00:00';
}
async function loadArchive() {
  const generation=++archiveLoadGeneration,date=$('archive-date').value,camera=activeCamera;
  if(loadedArchiveDate!==null&&loadedArchiveDate!==date)clearTimelineSelection();
  if(loadedArchiveDate!==null&&loadedArchiveDate!==date){playbackGeneration++;$('archive-player').pause();$('archive-player').removeAttribute('src');resetArchiveContents();loadedArchiveDate=null;}
  try {
    const current=()=>generation===archiveLoadGeneration&&camera===activeCamera&&date===$('archive-date').value;
    notify('');const [recordingData,eventData]=await Promise.all([archivePages(`/api/cameras/${camera.id}/recordings?date=${encodeURIComponent(date)}`,'recordings',current),archivePages(`/api/cameras/${camera.id}/events?date=${encodeURIComponent(date)}`,'events',current)]);
    if(generation!==archiveLoadGeneration||camera!==activeCamera||date!==$('archive-date').value)return false;
    // The index can change while a recording is playing (rotation or a new
    // segment). Keep playback attached to its ID, not its previous row number.
    const player=$('archive-player'),playing=loadedArchiveDate===date&&player.currentSrc?records[recordPosition]:null;
    records=recordingData.recordings;eventMarkers=eventData.events;loadedArchiveDate=date;
    if(playing){
      const position=records.findIndex(record=>record.id===playing.id);
      if(position>=0)recordPosition=position;
      else {playbackGeneration++;player.pause();player.removeAttribute('src');recordPosition=0;}
    }
    const container=$('recordings');container.replaceChildren();
    records.forEach((record,index)=>{
      const utc=record.utc_first&&!record.utc_second?' | UTC '+record.utc_first.replace('T',' ').replace('+00:00',''):' | czas UTC niejednoznaczny';
      const row=element('div',null,'recording-row');row.append(element('span',record.local_time.replace('T',' ')+' | '+Math.round(record.duration)+' s'+utc));
      const play=element('button','Odtwórz');play.addEventListener('click',()=>playRecord(index));row.append(play);
      if(activeCamera.may_download){const download=element('a','Pobierz plik');download.href=`/api/recordings/${record.id}/file?download=1`;download.setAttribute('download','');row.append(download);
        const protect=element('button',record.protected?'Usuń ochronę':'Chroń');protect.addEventListener('click',async()=>{protect.disabled=true;try{await api(`/api/recordings/${record.id}/protection`,record.protected?'DELETE':'POST',record.protected?null:{});if(camera===activeCamera&&date===$('archive-date').value)await loadArchive();}catch(e){if(camera===activeCamera&&date===$('archive-date').value)notify(e.message);}finally{protect.disabled=false;}});row.append(protect);}
      container.append(row);
    });
    if (!records.length) container.append(element('p','Brak nagrań dla wybranego dnia.'));
    renderTimeline();renderEvents();return true;
  } catch(e){if(generation===archiveLoadGeneration&&camera===activeCamera&&date===$('archive-date').value)notify(e.message);return false;}
}
function playRecord(index,offset=0) {
  if(!records[index])return;
  recordPosition=index;const player=$('archive-player'),generation=++playbackGeneration;player.src=`/api/recordings/${records[index].id}/file`;
  player.addEventListener('loadedmetadata',()=>{if(generation!==playbackGeneration)return;player.playbackRate=Number($('playback-speed').value);player.currentTime=offset;player.play().catch(()=>{});},{once:true});
}
function cameraDay(at=Date.now()){
  const parts=new Intl.DateTimeFormat('en-GB',{timeZone:me.timezone,year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date(at));
  const value=(type)=>parts.find(part=>part.type===type).value;
  return `${value('year')}-${value('month')}-${value('day')}`;
}
function seconds(text){const parts=text.split('T'),t=parts[1].split(':').map(Number);const offset=parts[0]<$('archive-date').value?-86400:parts[0]>$('archive-date').value?86400:0;return offset+t[0]*3600+t[1]*60+t[2];}
function clock(value){const n=Math.max(0,Math.min(86399,Number(value)));return [Math.floor(n/3600),Math.floor(n%3600/60),n%60].map(x=>String(x).padStart(2,'0')).join(':');}
function clearTimelineSelection(){timelineSelection=null;$('timeline-selection').textContent='';}
function rememberTimelineSelection(position){
  timelineSelection={date:$('archive-date').value,position:Number(position),fold:$('timeline-fold').value};
  $('timeline-selection').textContent='Zaznaczono: '+timelineSelection.date+' '+clock(timelineSelection.position);
}
async function timelineMatch(value){
  const date=$('archive-date').value,fold=$('timeline-fold').value;
  const result=await api('/api/time/resolve','POST',{local:date+'T'+clock(value),fold:fold===''?null:Number(fold)});
  const instant=Date.parse(result.utc)/1000;
  if(!Number.isFinite(instant))throw new Error('Nieprawidłowy czas osi.');
  const index=records.findIndex(record=>containsInstant(record,instant));
  if(index<0)return null;
  if(records[index].utc_second)throw new Error('Starsze nagranie ma niejednoznaczny czas i nie da się ustalić jego wystąpienia.');
  return {index,offset:instant-Date.parse(records[index].utc_first)/1000};
}
function timelineSpans(record){
  const parts=$('archive-date').value.split('-').map(Number),day=Date.UTC(parts[0],parts[1]-1,parts[2])/1000;
  if(timelineFormatterZone!==me.timezone){timelineFormatterZone=me.timezone;timelineFormatter=new Intl.DateTimeFormat('en-GB',{timeZone:me.timezone,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'});}
  function offset(instant){
    const fields=timelineFormatter.formatToParts(new Date(instant*1000));const get=name=>Number(fields.find(field=>field.type===name).value);
    return Date.UTC(get('year'),get('month')-1,get('day'),get('hour'),get('minute'),get('second'))/1000-Math.floor(instant);
  }
  const spans=[];
  for(const timestamp of [record.utc_first,record.utc_second]){
    if(!timestamp)continue;
    let start=Date.parse(timestamp)/1000,end=start+Number(record.duration);
    if(!Number.isFinite(start)||!Number.isFinite(end)||end<=start)continue;
    while(start<end){
      const current=offset(start),last=offset(Math.max(start,end-0.001));let boundary=end;
      if(current!==last){
        let low=start,high=end;
        while(high-low>0.001){const mid=(low+high)/2;if(offset(mid)===current)low=mid;else high=mid;}
        boundary=high;
      }
      const left=Math.max(0,start+current-day),right=Math.min(86400,boundary+current-day);
      if(right>left)spans.push([left,right]);
      start=boundary;
    }
  }
  return spans;
}
function renderTimeline(){
  const track=$('timeline-track');track.replaceChildren();
  for(const record of records)for(const [start,end] of timelineSpans(record)){const block=element('span',null,'timeline-segment');block.style.left=(start/86400*100)+'%';block.style.width=((end-start)/86400*100)+'%';track.append(block);}
  const selected=$('event-filter').value;
  for(const event of eventMarkers.filter(item=>selected==='all'||item.type===selected)){const position=eventSeconds(event.timestamp);const marker=element('span',null,'timeline-event');marker.style.left=(position/86400*100)+'%';marker.title=event.type;track.append(marker);}
  if(records.some(r=>r.utc_second))notify('Uwaga: część nagrań ma niejednoznaczną godzinę po zmianie czasu.');
}
function eventSeconds(timestamp){const pieces=new Intl.DateTimeFormat('en-GB',{timeZone:me.timezone,hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).formatToParts(new Date(timestamp*1000));const get=(type)=>Number(pieces.find(p=>p.type===type).value);return get('hour')*3600+get('minute')*60+get('second');}
function renderEvents(){
  const area=$('events');area.replaceChildren();const selected=$('event-filter').value;const labels={motion:'Ruch',person:'Osoba',vehicle:'Pojazd',animal:'Zwierzę'};
  for(const event of eventMarkers.filter(e=>selected==='all'||e.type===selected)){
    const fold=event.fold===0||event.fold===1?String(event.fold):'';
    const suffix=fold===''?'':` (${Number(fold)+1}. wystąpienie)`;
    const button=element('button',clock(eventSeconds(event.timestamp))+suffix+' - '+(labels[event.type]||event.type));
    button.addEventListener('click',()=>{
      const position=eventSeconds(event.timestamp);
      timelineRequestGeneration++;clearTimeout(previewTimer);$('timeline-preview').hidden=true;
      $('timeline-fold').value=fold;$('timeline-position').value=String(position);$('timeline-time').textContent=clock(position);
      rememberTimelineSelection(position);
      const index=records.findIndex(r=>!r.utc_second&&r.utc_first&&Date.parse(r.utc_first)/1000<=event.timestamp&&event.timestamp<Date.parse(r.utc_first)/1000+r.duration);
      if(index>=0)playRecord(index,event.timestamp-Date.parse(records[index].utc_first)/1000);else notify('Brak jednoznacznego nagrania dla tego zdarzenia.');
    });area.append(button);
  }
}
$('event-filter').addEventListener('change',()=>{renderEvents();renderTimeline();});
$('event-token-create').addEventListener('click',async()=>{if(!window.confirm('Utworzenie tokenu unieważni poprzedni. Kontynuować?'))return;try{const result=await api('/api/integrations/events/token','POST',{});$('event-token').value=result.token;notify('Token pokazany tylko teraz. Skopiuj go w bezpieczne miejsce.');}catch(error){notify(error.message);}});
$('event-token-revoke').addEventListener('click',async()=>{if(!window.confirm('Unieważnić token zdarzeń?'))return;try{await api('/api/integrations/events/token','DELETE');$('event-token').value='';notify('Token unieważniony.');}catch(error){notify(error.message);}});
let previewTimer=null;
$('timeline-position').addEventListener('input',(event)=>{
  const position=Number(event.target.value),camera=activeCamera,generation=archiveLoadGeneration,request=++timelineRequestGeneration;
  rememberTimelineSelection(position);
  $('timeline-time').textContent=clock(position);clearTimeout(previewTimer);$('timeline-preview').hidden=true;
  previewTimer=setTimeout(async()=>{
    try{
      const match=await timelineMatch(position);
      if(request!==timelineRequestGeneration||camera!==activeCamera||generation!==archiveLoadGeneration||!match)return;
      const image=$('timeline-preview');image.src=`/api/recordings/${records[match.index].id}/frame?offset=${match.offset}`;image.hidden=false;
    }catch(error){/* A preview is optional; the selection reports errors. */}
  },300);
});
$('timeline-position').addEventListener('change',async(event)=>{
  const position=Number(event.target.value),camera=activeCamera,generation=archiveLoadGeneration,request=++timelineRequestGeneration;
  rememberTimelineSelection(position);
  clearTimeout(previewTimer);$('timeline-preview').hidden=true;
  try{
    const match=await timelineMatch(position);
    if(request!==timelineRequestGeneration||camera!==activeCamera||generation!==archiveLoadGeneration)return;
    if(match)playRecord(match.index,match.offset);else notify('Brak nagrania w wybranym czasie.');
  }catch(error){if(request===timelineRequestGeneration&&camera===activeCamera&&generation===archiveLoadGeneration)notify(error.message);}
});
$('timeline-fold').addEventListener('change',()=>{timelineRequestGeneration++;clearTimeout(previewTimer);$('timeline-preview').hidden=true;if(timelineSelection)timelineSelection.fold=$('timeline-fold').value;});
function setExportBoundary(which){
  const selection=timelineSelection||{date:$('archive-date').value,position:Number($('timeline-position').value),fold:$('timeline-fold').value};
  $('export-form').elements[which].value=selection.date+'T'+clock(selection.position);
  $('export-form').elements[which+'_fold'].value=selection.fold;
  clearTimelineSelection();
}
$('set-export-start').addEventListener('click',()=>setExportBoundary('start'));
$('set-export-end').addEventListener('click',()=>setExportBoundary('end'));
$('save-frame').addEventListener('click',()=>{
  const record=records[recordPosition],player=$('archive-player');
  if(!activeCamera||!activeCamera.may_download||!record)return;
  try{
    const current=new URL(player.currentSrc,location.origin);
    if(current.origin!==location.origin||current.pathname!==`/api/recordings/${record.id}/file`||player.readyState<2||!Number.isFinite(player.currentTime))throw new Error();
  }catch{notify('Najpierw uruchom nagranie i poczekaj na obraz.');return;}
  const a=element('a');a.href=`/api/recordings/${record.id}/frame?offset=${Math.max(0,player.currentTime)}&download=1`;a.click();
});
function labeledInput(labelText,type,value=''){
  const label=element('label',labelText);const input=element('input');input.type=type;input.value=value;label.append(input);return {label,input};
}
async function refreshAdmin() {
  const generation=++adminRefreshGeneration;
  const {users,accounts,cameras:adminCameras}=await api('/api/admin/inventory');
  if(generation!==adminRefreshGeneration)return;
  const [ha,storage,monitoring,audit]=await Promise.all([api('/api/settings/home-assistant'),api('/api/settings/storage'),api('/api/settings/monitoring'),api('/api/audit')]);
  if(generation!==adminRefreshGeneration)return;
  const ftpSelect=$('ftp-camera'),previousFtp=ftpSelect.value;
  ftpSelect.replaceChildren(new Option('Wspólne',''));
  for(const camera of adminCameras)ftpSelect.add(new Option(camera.name,String(camera.id)));
  ftpSelect.value=adminCameras.some(camera=>String(camera.id)===previousFtp)?previousFtp:'';
  const usersBox=$('users');usersBox.replaceChildren();
  for(const user of users){
    const details=element('details');details.append(element('summary',user.username+' - '+user.role+(user.enabled?'':' - wyłączony')));
    const role=element('select');role.add(new Option('Użytkownik','viewer'));role.add(new Option('Administrator','admin'));role.value=user.role;const roleLabel=element('label','Rola');roleLabel.append(role);details.append(roleLabel);const roleSave=element('button','Zmień rolę');roleSave.type='button';roleSave.addEventListener('click',async()=>{try{await api(`/api/users/${user.id}`,'PATCH',{role:role.value});await refreshAdmin();}catch(error){notify(error.message);}});details.append(roleSave);
    const toggle=element('button',user.enabled?'Wyłącz konto':'Włącz konto');toggle.type='button';toggle.addEventListener('click',async()=>{try{await api(`/api/users/${user.id}`,'PATCH',{enabled:!user.enabled});await refreshAdmin();}catch(error){notify(error.message);}});details.append(toggle);
    const change=labeledInput('Nowe hasło','password');details.append(change.label);const save=element('button','Zmień hasło');save.type='button';save.addEventListener('click',async()=>{try{await api(`/api/users/${user.id}`,'PATCH',{password:change.input.value});change.input.value='';notify('Hasło zmienione.');}catch(error){notify(error.message);}});details.append(save);
    if(user.role!=='admin'){
      const grants=user.permissions;const list=element('div');const controls=[];
      for(const camera of adminCameras){const current=grants.find(g=>g.id===camera.id);const label=element('label',camera.name,'inline');const access=element('input');access.type='checkbox';access.checked=Boolean(current);label.prepend(access);const downloadLabel=element('label','Pobieranie','inline');const download=element('input');download.type='checkbox';download.checked=Boolean(current&&current.download);downloadLabel.prepend(download);list.append(label,downloadLabel);controls.push({id:camera.id,access,download});}
      const apply=element('button','Zapisz uprawnienia');apply.type='button';apply.addEventListener('click',async()=>{try{await api(`/api/users/${user.id}/permissions`,'POST',{cameras:controls.filter(c=>c.access.checked).map(c=>({id:c.id,download:c.download.checked}))});notify('Uprawnienia zapisane.');}catch(error){notify(error.message);}});details.append(list,element('p','Wyłączenie pobierania ukrywa funkcje zapisu, ale osoba mająca dostęp do odtwarzania może skopiować obraz.'),apply);
    }
    usersBox.append(details);
  }
  $('ha-form').elements.url.value=ha.url;$('ha-form').elements.enabled.checked=ha.enabled;
  $('archive-path').textContent='Nagrania: '+storage.archive+' | Eksporty: '+storage.exports;
  $('archive-form').elements.archive.value=storage.archive;
  $('archive-form').elements.exports.value=storage.exports;
  $('monitoring-form').elements.stale_after.value=monitoring.stale_after;
  $('monitoring-config-status').textContent=monitoring.invalid?'Nieprawidłowy zapis ustawienia - używany jest domyślny czas 900 sekund. Zapisz poprawną wartość.':'';
  $('storage-change-status').textContent=storage.change_pending?'Zmiana katalogu oczekuje na przetworzenie.':storage.change_status.message||'';

  $('storage-form').elements.minimum.value=storage.limits_invalid?'':storage.minimum_free/1e9;$('storage-form').elements.buffer.value=storage.limits_invalid?'':storage.free_buffer/1e9;
  $('storage-limit-status').textContent=storage.limits_invalid?'Nieprawidłowe limity dysku. Zapis i rotacja są wstrzymane. Wprowadź i zapisz poprawne wartości.':'';
  const ftpBox=$('ftp-accounts');ftpBox.replaceChildren();
  for(const account of accounts){const details=element('details');details.append(element('summary',account.username+(account.camera_id?' - kamera '+account.camera_id:' - wspólne')+(account.enabled?'':' - wyłączone')));
    const toggle=element('button',account.enabled?'Wyłącz':'Włącz');toggle.type='button';toggle.addEventListener('click',async()=>{try{await api(`/api/ftp-accounts/${account.id}`,'PATCH',{enabled:!account.enabled});await refreshAdmin();}catch(error){notify(error.message);}});details.append(toggle);
    const password=labeledInput('Nowe hasło FTP','password');details.append(password.label);const save=element('button','Zmień hasło');save.type='button';save.addEventListener('click',async()=>{try{await api(`/api/ftp-accounts/${account.id}`,'PATCH',{password:password.input.value});password.input.value='';notify('Hasło FTP zmienione.');}catch(error){notify(error.message);}});details.append(save);
    const home=element('select');home.add(new Option('Wspólny katalog nagrań',''));for(const camera of adminCameras)home.add(new Option(camera.name,String(camera.id)));home.value=account.camera_id===null?'':String(account.camera_id);
    const homeLabel=element('label','Katalog konta FTP');homeLabel.append(home);details.append(homeLabel);
    const homeSave=element('button','Zmień katalog konta');homeSave.type='button';homeSave.addEventListener('click',async()=>{if(!window.confirm('Zmiana katalogu może wymagać zmiany ścieżki FTP w kamerach. Kontynuować?'))return;try{await api(`/api/ftp-accounts/${account.id}`,'PATCH',{camera_id:home.value?Number(home.value):null});await refreshAdmin();notify('Zapisano zmianę. Usługa FTP zastosuje ją po aktualizacji konfiguracji.');}catch(error){notify(error.message);}});details.append(homeSave);
    const remove=element('button','Usuń konto FTP');remove.type='button';remove.addEventListener('click',async()=>{if(!window.confirm('Usunąć konto FTP '+account.username+'?'))return;try{await api(`/api/ftp-accounts/${account.id}`,'DELETE');await refreshAdmin();}catch(error){notify(error.message);}});details.append(remove);ftpBox.append(details);
  }
  const cameraBox=$('manage-cameras');cameraBox.replaceChildren();
  for(const camera of adminCameras){const data=camera;const assigned=camera.accounts;
    const details=element('details');details.append(element('summary',camera.name+' - '+camera.slug));
    const name=labeledInput('Nazwa','text',camera.name),main=labeledInput('Nowy adres RTSP główny - puste zachowuje obecny','text'),sub=labeledInput('Nowy adres RTSP pomocniczy - puste zachowuje obecny','text');details.append(name.label,main.label,sub.label);
    const cameraUser=labeledInput('Nowy użytkownik kamery - puste zachowuje dane','text'),cameraPassword=labeledInput('Nowe hasło kamery','password');cameraPassword.input.autocomplete='new-password';details.append(cameraUser.label,cameraPassword.label);
    const clear=element('input');clear.type='checkbox';const clearLabel=element('label','Usuń strumień pomocniczy','inline');clearLabel.prepend(clear);details.append(clearLabel);
    const mode=element('select');for(const [value,text] of [['ftp','FTP'],['rtsp','RTSP'],['none','Bez zapisu']])mode.add(new Option(text,value));mode.value=data.recording;const modeLabel=element('label','Nagrywanie');modeLabel.append(mode);details.append(modeLabel);
    const save=element('button','Zapisz kamerę');save.type='button';save.addEventListener('click',async()=>{try{const values={name:name.input.value,recording:mode.value};if(main.input.value)values.main_url=main.input.value;if(clear.checked)values.sub_url='';else if(sub.input.value)values.sub_url=sub.input.value;if(cameraUser.input.value||cameraPassword.input.value){values.username=cameraUser.input.value;values.password=cameraPassword.input.value;}await api(`/api/cameras/${camera.id}`,'PATCH',values);cameraPassword.input.value='';await refreshCameras();await refreshAdmin();notify('Kamera zapisana.');}catch(error){notify(error.message);}});details.append(save);
    const enable=element('button',camera.enabled?'Wyłącz kamerę':'Włącz kamerę');enable.type='button';enable.addEventListener('click',async()=>{try{await api(`/api/cameras/${camera.id}`,'PATCH',{enabled:!camera.enabled});await refreshCameras();await refreshAdmin();}catch(error){notify(error.message);}});details.append(enable);
    const labels=element('div');const choices=[];for(const account of accounts){if(account.camera_id&&account.camera_id!==camera.id)continue;const label=element('label',account.username,'inline');const check=element('input');check.type='checkbox';check.checked=assigned.includes(account.id);label.prepend(check);labels.append(label);choices.push({id:account.id,check});}details.append(element('p','Konta FTP - przypisanie informacyjne. Konto wspólne ma dostęp do całego katalogu nagrań, a konto kamery tylko do jej katalogu.'),labels);
    const assign=element('button','Zapisz konta FTP');assign.type='button';assign.addEventListener('click',async()=>{try{await api(`/api/cameras/${camera.id}/ftp-accounts`,'POST',{accounts:choices.filter(c=>c.check.checked).map(c=>c.id)});notify('Przypisanie FTP zapisane.');}catch(error){notify(error.message);}});details.append(assign);
    const onvif=camera.onvif;const clockDetails=element('details');clockDetails.append(element('summary','Kontrola czasu ONVIF'));
    const endpoint=labeledInput('Adres usługi ONVIF','url',onvif.url),onvifUser=labeledInput('Użytkownik ONVIF','text',onvif.username),onvifPassword=labeledInput(onvif.password_configured?'Nowe hasło ONVIF - puste zachowuje obecne':'Hasło ONVIF','password');
    endpoint.input.placeholder='http://192.168.1.10/onvif/device_service';clockDetails.append(endpoint.label,onvifUser.label,onvifPassword.label);
    const auth=element('select');auth.add(new Option('HTTP Digest','digest'));auth.add(new Option('WS-Security UsernameToken','wsse'));auth.value=onvif.auth_mode;const authLabel=element('label','Uwierzytelnianie ONVIF');authLabel.append(auth);clockDetails.append(authLabel,element('p','UsernameToken to starsza metoda o słabszych zabezpieczeniach. Używaj jej w zaufanej sieci lub przez HTTPS. Kamera może odmówić dostępu, jeśli jej czas znacznie różni się od czasu serwera.'));
    let clockStatus='Czas kamery nie został jeszcze sprawdzony.';
    if(onvif.checked!==null&&onvif.fresh===false)clockStatus='Brak aktualnego odczytu czasu ONVIF.';
    else if(onvif.error)clockStatus=onvif.error;else if(onvif.checked!==null&&onvif.offset!==null)clockStatus=`Różnica czasu: ${Number(onvif.offset).toFixed(1)} s. Sprawdzono: ${new Date(onvif.checked*1000).toLocaleString('pl-PL')}.`;
    clockDetails.append(element('p',clockStatus));const clockSave=element('button','Zapisz ustawienia ONVIF');clockSave.type='button';clockSave.addEventListener('click',async()=>{try{await api(`/api/cameras/${camera.id}/onvif`,'PATCH',{url:endpoint.input.value,username:onvifUser.input.value,password:onvifPassword.input.value,auth_mode:auth.value});onvifPassword.input.value='';notify('Ustawienia ONVIF zapisane.');}catch(error){notify(error.message);}});clockDetails.append(clockSave);details.append(clockDetails);
    const remove=element('button','Usuń kamerę z konfiguracji');remove.type='button';remove.addEventListener('click',async()=>{if(!window.confirm('Usunąć kamerę z konfiguracji? Pliki nagrań pozostaną na dysku.'))return;try{await api(`/api/cameras/${camera.id}`,'DELETE');await refreshCameras();await refreshAdmin();}catch(error){notify(error.message);}});details.append(remove);cameraBox.append(details);
  }
  const events=audit.events;$('audit').replaceChildren();for(const event of events)$('audit').append(element('p',new Date(event.timestamp*1000).toLocaleString()+' | '+event.user_id+' | '+event.action+' | '+event.object_type+' '+event.object_id));
  const results=await Promise.allSettled([refreshDomain(),refreshTLS(),refreshRotation(),refreshServices(),refreshUpgradeStatus()]);
  if(generation!==adminRefreshGeneration)return;
  const upgrade=results[4];if(upgrade.status==='fulfilled'&&(upgrade.value.pending||['verifying','applying','recovery_required'].includes(upgrade.value.status.state)))watchUpgrade();
  const failed=results.find(result=>result.status==='rejected');if(failed)notify('Nie udało się odświeżyć części statusów: '+failed.reason.message);
}

// Periodically confirm the identity and privileges displayed by the panel.
// Reload on a security-context change so no previous account's player,
// archive, exports, credentials or pending callbacks remain in the DOM.
async function refreshUserContext(){
  const previous=me;if(!previous)return false;
  let current;
  try{current=await api('/api/me');}
  catch(error){if(error.status===401&&me===previous){location.reload();return false;}throw error;}
  if(me!==previous)return false;
  if(current.id!==previous.id||current.role!==previous.role){location.reload();return false;}
  if(!$('archive-view').hidden||!$('sync-view').hidden){
    const incoming=(await api('/api/cameras')).cameras;
    if(me!==previous)return false;
    const grants=list=>JSON.stringify(list.map(c=>[c.id,c.may_download]).sort((a,b)=>a[0]-b[0]));
    if(grants(cameras)!==grants(incoming)){location.reload();return false;}
  }
  return true;
}

async function start() {
  try {me=await api('/api/me');}
  catch(error) {me=null;$('signed-in-user').textContent='';$('login-panel').hidden=false;$('application').hidden=true;$('logout').hidden=true;if(error.status!==401)notify(error.message);try{$('setup-panel').hidden=!(await api('/api/setup')).available;}catch{$('setup-panel').hidden=true;}return;}
  $('login-panel').hidden=true;$('application').hidden=false;$('logout').hidden=false;$('show-admin').hidden=me.role!=='admin';$('signed-in-user').textContent=me.username+' - '+(me.role==='admin'?'administrator':'użytkownik');view('cameras');
  try{await refreshCameras();await refreshExports();}catch(error){notify('Nie udało się wczytać kamer: '+error.message);}
}
$('refresh-cameras').addEventListener('click',async()=>{try{await refreshCameras();notify('Lista kamer odświeżona.');}catch(error){notify(error.message);}});
$('login-form').addEventListener('submit',async(event)=>{event.preventDefault();try{notify('');await api('/api/login','POST',formData(event.target));event.target.reset();await start();}catch(e){notify(e.message);}});
$('setup-form').addEventListener('submit',async(event)=>{event.preventDefault();const value=formData(event.target);
  if(value.password!==value.confirmation){notify('Hasła nie są identyczne.');return;}
  try{await api('/api/setup','POST',{token:value.token,username:value.username,password:value.password});event.target.reset();$('setup-panel').hidden=true;notify('Administrator utworzony. Możesz się zalogować.');}
  catch(error){notify(error.message);}
});
$('logout').addEventListener('click',async()=>{try{await api('/api/logout','POST',{});location.reload();}catch(e){notify(e.message);}});
$('own-password-form').addEventListener('submit',async(event)=>{
  event.preventDefault();const form=event.target;
  if(form.elements.new.value!==form.elements.confirmation.value){notify('Nowe hasła nie są identyczne.');return;}
  try{await api('/api/account/password','POST',{current:form.elements.current.value,new:form.elements.new.value});form.reset();location.reload();}
  catch(error){notify(error.message);}
});
$('layout-select').addEventListener('change',renderCameras);
$('layout-form').addEventListener('submit',async(event)=>{event.preventDefault();try{const name=event.target.elements.name.value;const ids=Array.from($('layout-cameras').querySelectorAll('input:checked')).map(x=>Number(x.value));await api('/api/layouts','POST',{name,cameras:ids});event.target.reset();await refreshLayouts();notify('Układ zapisany.');}catch(error){notify(error.message);}});
$('delete-layout').addEventListener('click',async()=>{const id=$('layout-select').value;if(!id)return;try{await api(`/api/layouts/${id}`,'DELETE');await refreshLayouts();renderCameras();notify('Układ usunięty.');}catch(error){notify(error.message);}});
$('show-cameras').addEventListener('click',()=>view('cameras'));
$('back-cameras').addEventListener('click',()=>{ $('archive-player').pause();view('cameras');});
$('show-sync').addEventListener('click',openSync);
$('show-admin').addEventListener('click',async()=>{try{if(!me||me.role!=='admin')return;view('admin');await refreshAdmin();}catch(e){notify(e.message);}});
$('load-archive').addEventListener('click',loadArchive);
function containsInstant(record,instant){
  return [record.utc_first,record.utc_second].some(value=>value&&Date.parse(value)/1000<=instant&&instant<Date.parse(value)/1000+record.duration);
}
for(const button of document.querySelectorAll('[data-recent]'))button.addEventListener('click',async()=>{
  const target=Date.now()/1000-Number(button.dataset.recent)*60;$('archive-date').value=cameraDay(target*1000);
  if(!await loadArchive())return;
  const index=records.findIndex(record=>containsInstant(record,target));
  if(index<0){notify('Brak ukończonego nagrania dla wybranego czasu.');return;}
  if(records[index].utc_second){notify('Czas nagrania jest niejednoznaczny po zmianie czasu.');return;}
  playRecord(index,target-Date.parse(records[index].utc_first)/1000);
});
async function playNextRecording(){
  const current=records[recordPosition];if(!current||!current.utc_first)return;
  if(current.utc_second){notify('Nie można automatycznie przejść przez niejednoznaczną godzinę po zmianie czasu.');return;}
  const end=Date.parse(current.utc_first)/1000+current.duration;
  let next=records.findIndex((record,index)=>index>recordPosition&&record.utc_first&&Date.parse(record.utc_first)/1000+record.duration>end+0.05);
  if(next<0){
    const generation=playbackGeneration,camera=activeCamera,date=$('archive-date').value;
    const upcoming=await api(`/api/cameras/${camera.id}/next-recording?after_ms=${Math.floor(end*1000)}&exclude=${current.id}`);
    if(generation!==playbackGeneration||camera!==activeCamera||date!==$('archive-date').value)return;
    const candidate=upcoming.recording;
    if(!candidate)return;
    if(candidate.utc_second){notify('Kolejne nagranie ma niejednoznaczną godzinę po zmianie czasu.');return;}
    $('archive-date').value=cameraDay(Date.parse(candidate.utc_first));if(!await loadArchive())return;
    next=records.findIndex(record=>record.id===candidate.id);
  }
  if(next<0)return;
  const record=records[next];if(record.utc_second){notify('Kolejne nagranie ma niejednoznaczną godzinę po zmianie czasu.');return;}
  const start=Date.parse(record.utc_first)/1000;if(start>end+1)notify('Między nagraniami występuje przerwa.');
  playRecord(next,Math.max(0,end-start));
}
$('archive-player').addEventListener('ended',()=>{playNextRecording().catch(error=>notify(error.message));});
$('archive-player').addEventListener('timeupdate',()=>{const record=records[recordPosition],player=$('archive-player');if(!record||!player.currentSrc||!record.utc_first||record.utc_second)return;const instant=Date.parse(record.utc_first)+player.currentTime*1000;if(!Number.isFinite(instant)||cameraDay(instant)!==$('archive-date').value)return;const position=eventSeconds(instant/1000);$('timeline-position').value=String(position);$('timeline-time').textContent=clock(position);});
$('playback-speed').addEventListener('change',event=>{$('archive-player').playbackRate=Number(event.target.value);});
async function seekArchive(delta){
  const record=records[recordPosition],player=$('archive-player');if(!record||!player.currentSrc||!record.utc_first)return;
  if(record.utc_second){notify('Nie można przewijać przez niejednoznaczną godzinę po zmianie czasu.');return;}
  const target=Date.parse(record.utc_first)/1000+player.currentTime+delta;
  if(!Number.isFinite(target))return;
  const day=cameraDay(target*1000),camera=activeCamera;
  if(day!==$('archive-date').value){$('archive-date').value=day;if(!await loadArchive()||activeCamera!==camera)return;}
  const index=records.findIndex(r=>containsInstant(r,target));
  if(index<0){notify('Brak nagrania w wybranym czasie.');return;}
  if(records[index].utc_second){notify('Wybrany czas jest niejednoznaczny po zmianie czasu.');return;}
  const offset=target-Date.parse(records[index].utc_first)/1000;
  if(records[index].id===record.id&&player.currentSrc)player.currentTime=offset;else playRecord(index,offset);
}
for(const button of document.querySelectorAll('[data-seek]'))button.addEventListener('click',()=>{seekArchive(Number(button.dataset.seek)).catch(error=>notify(error.message));});
$('camera-form').addEventListener('submit',async(event)=>{event.preventDefault();try{await api('/api/cameras','POST',formData(event.target));event.target.reset();await Promise.all([refreshCameras(),refreshAdmin()]);notify('Kamera dodana.');}catch(e){notify(e.message);}});
$('user-form').addEventListener('submit',async(event)=>{event.preventDefault();try{await api('/api/users','POST',formData(event.target));event.target.reset();await refreshAdmin();notify('Użytkownik dodany.');}catch(e){notify(e.message);}});
$('ftp-form').addEventListener('submit',async(event)=>{event.preventDefault();try{const data=formData(event.target);data.camera_id=data.camera_id?Number(data.camera_id):null;await api('/api/ftp-accounts','POST',data);event.target.reset();await refreshAdmin();notify('Konto FTP dodane do konfiguracji.');}catch(e){notify(e.message);}});
async function refreshUpgradeStatus(){
  const value=await api('/api/updates');const status=value.status;
  $('upgrade-status').textContent='Wersja '+(value.version||'')+' | '+(value.pending?'Aktualizacja oczekuje na uruchomienie.':status.message||'Brak oczekującej aktualizacji.');
  const select=$('upgrade-form').elements.package,chosen=select.value;
  select.replaceChildren();for(const name of (value.packages||[])){const option=element('option',name);option.value=name;select.append(option);}
  if((value.packages||[]).includes(chosen))select.value=chosen;
  $('upgrade-form').querySelector('button[type="submit"]').disabled=value.pending||!(value.packages||[]).length;
  return value;
}
async function refreshDomain(){
  const value=await api('/api/settings/domain');
  $('domain-current').textContent='Aktualny adres: '+value.origin;
  $('domain-form').querySelector('button').disabled=!value.supported||value.pending||['applying','recovery_required'].includes(value.status.state);
  $('domain-status').textContent=!value.supported?'Ta instalacja wymaga migracji mechanizmu odzyskiwania przed zmianą domeny.':value.pending?'Zmiana domeny oczekuje na przetworzenie.':value.status.message||'Brak oczekującej zmiany domeny.';
  return value;
}
$('domain-refresh').addEventListener('click',async()=>{try{await refreshDomain();}catch(error){notify(error.message);}});
$('domain-form').addEventListener('submit',async(event)=>{
  event.preventDefault();const form=event.target,button=form.querySelector('button');let queued=false;button.disabled=true;
  try{await api('/api/settings/domain','POST',{hostname:form.elements.hostname.value});queued=true;form.reset();await refreshDomain();notify('Zmiana domeny oczekuje na sprawdzenie.');}
  catch(error){notify(error.message);}finally{if(!queued)button.disabled=false;}
});
async function refreshTLS(){
  const value=await api('/api/settings/tls');$('tls-status').textContent=value.pending?'Zmiana certyfikatu oczekuje na przetworzenie.':value.status.message||'Brak oczekującej zmiany certyfikatu.';
  return value;
}
$('tls-refresh').addEventListener('click',async()=>{try{await refreshTLS();}catch(error){notify(error.message);}});
$('tls-form').addEventListener('submit',async(event)=>{
  event.preventDefault();const form=event.target,button=form.querySelector('button');button.disabled=true;
  try{
    const cert=form.elements.certificate.files[0],key=form.elements.key.files[0];
    if(!cert||!key||cert.size+key.size>80*1024)throw new Error('Wybierz certyfikat i klucz o łącznym rozmiarze do 80 KiB.');
    await api('/api/settings/tls','POST',{certificate:await cert.text(),key:await key.text()});form.reset();await refreshTLS();
    notify('Certyfikat oczekuje na sprawdzenie i instalację.');
  }catch(error){notify(error.message);}finally{button.disabled=false;}
});
let upgradePollTimer=null;
function watchUpgrade(){
  if(upgradePollTimer!==null)return;
  const poll=async()=>{
    upgradePollTimer=null;if(!me||$('admin-view').hidden)return;
    try{
      const result=await refreshUpgradeStatus();
      if(!result.pending&&!['verifying','applying','recovery_required'].includes(result.status.state))return;
    }catch{$('upgrade-status').textContent='Serwer jest niedostępny. Oczekiwanie na zakończenie aktualizacji...';}
    upgradePollTimer=setTimeout(poll,5000);
  };
  upgradePollTimer=setTimeout(poll,5000);
}
async function refreshRotation(){
  const data=await api('/api/rotation'),labels={unknown:'Brak zapisanych operacji',rotation_ok:'Rotacja działa poprawnie',rotation_blocked:'Nie udało się odzyskać wymaganego miejsca',rotation_error:'Błąd rotacji'};
  const latest=data.history[0];let status=labels[data.state]||'Brak danych';
  if(data.state==='rotation_blocked'&&latest&&latest.state==='rotation_blocked'&&latest.protected_count)
    status+=`. Pominięto ${latest.protected_count} chronionych plików (${(latest.protected_bytes/1e9).toFixed(2)} GB).`;
  $('rotation-state').textContent=status;const box=$('rotation-history');box.replaceChildren();
  for(const item of data.history){const before=item.before===null?'-':(item.before/1e9).toFixed(2)+' GB',after=item.after===null?'-':(item.after/1e9).toFixed(2)+' GB';box.append(element('p',`${new Date(item.created*1000).toLocaleString('pl-PL')} | ${labels[item.state]||item.state} | usunięto: ${item.files_count} | wolne: ${before} do ${after} | chronione: ${item.protected_count} (${(item.protected_bytes/1e9).toFixed(2)} GB)`));}
  if(!data.history.length)box.append(element('p','Brak historii rotacji.'));
}
async function refreshServices(){
  const value=await api('/api/system/health'),box=$('service-status');box.replaceChildren();
  const labels={active:'działa',inactive:'awaria lub usługa zatrzymana',unknown:'brak danych'};
  for(const service of value.services)box.append(element('p',`${service.name}: ${service.fresh===false?'brak aktualnych danych':(labels[service.state]||'brak danych')}`));
  if(!value.services.length)box.append(element('p','Oczekiwanie na pierwsze sprawdzenie usług.'));
  const problems={disk_unavailable:'Dysk nagrań niedostępny',disk_low:'Mało wolnego miejsca',rotation_blocked:'Rotator nie może zwolnić wymaganego miejsca',rotation_error:'Błąd rotatora',monitor_error:'Nie można sprawdzić usług',stream_service_error:'Serwer strumieni niedostępny',ha_delivery_error:'Ostatnia próba wysłania powiadomienia do Home Assistanta nie powiodła się'};
  for(const item of value.system){
    if(problems[item.state])box.append(element('p',problems[item.state]));
    else if(item.name.startsWith('clock:')&&item.fresh===false){
      const camera=cameras.find(c=>String(c.id)===item.name.slice(6));
      box.append(element('p','Brak aktualnego odczytu czasu ONVIF: '+(camera?camera.name:item.name.slice(6))));
    }
    else if(item.state==='clock_skew'&&item.name.startsWith('clock:')){
      const camera=cameras.find(c=>String(c.id)===item.name.slice(6));
      box.append(element('p','Różnica czasu kamery: '+(camera?camera.name:item.name.slice(6))));
    }
    else if(item.state==='clock_unavailable'&&item.name.startsWith('clock:')){
      const camera=cameras.find(c=>String(c.id)===item.name.slice(6));
      box.append(element('p','Nie można odczytać czasu ONVIF: '+(camera?camera.name:item.name.slice(6))));
    }
    else if(item.state==='recording_corrupt'&&item.name.startsWith('recorder_corrupt:')){
      const slug=item.name.slice('recorder_corrupt:'.length),camera=cameras.find(c=>c.slug===slug);
      box.append(element('p','Nie można odczytać segmentu RTSP: '+(camera?camera.name:slug)+'. Plik pozostawiono do sprawdzenia.'));
    }
    else if(item.state==='recording_publish_error'&&item.name.startsWith('recorder_publish:')){
      const slug=item.name.slice('recorder_publish:'.length),camera=cameras.find(c=>c.slug===slug);
      box.append(element('p','Nie można zapisać segmentu RTSP w archiwum: '+(camera?camera.name:slug)+'. Plik pozostawiono w katalogu roboczym.'));
    }
    else if(item.state==='recording_staging_error'&&item.name.startsWith('recorder_staging:')){
      const slug=item.name.slice('recorder_staging:'.length),camera=cameras.find(c=>c.slug===slug);
      box.append(element('p','Nie można przygotować katalogu zapisu RTSP: '+(camera?camera.name:slug)+'. Pozostałe kamery pracują niezależnie.'));
    }
    else if(item.state==='recording_audio_missing'&&item.name.startsWith('recorder_audio:')){
      const slug=item.name.slice('recorder_audio:'.length),camera=cameras.find(c=>c.slug===slug);
      box.append(element('p','Ostatnio sprawdzony segment nie ma ścieżki audio: '+(camera?camera.name:slug)+'. Obraz został zachowany.'));
    }
    else if(item.state==='recording_process_error'&&item.name.startsWith('recorder_process:')){
      const slug=item.name.slice('recorder_process:'.length),camera=cameras.find(c=>c.slug===slug);
      box.append(element('p','Błąd procesu nagrywania RTSP: '+(camera?camera.name:slug)+'. Rejestrator ponawia próbę.'));
    }
  }
}
setInterval(async()=>{
  if(!me||document.hidden||statusRefreshPending)return;
  statusRefreshPending=true;
  try{
    if(!await refreshUserContext())return;
    if(!$('camera-view').hidden)await refreshCameraStatus();
    if(me.role==='admin'&&!$('admin-view').hidden)await refreshServices();
  }catch(error){notify(error.message);}finally{statusRefreshPending=false;}
},30000);
$('service-refresh').addEventListener('click',async()=>{try{await refreshServices();}catch(error){notify(error.message);}});
$('monitoring-form').addEventListener('submit',async(event)=>{
  event.preventDefault();const value=Number(event.target.elements.stale_after.value);
  if(!Number.isInteger(value)||value<60||value>86400){notify('Czas alarmu musi wynosić od 60 do 86400 sekund.');return;}
  try{await api('/api/settings/monitoring','PATCH',{stale_after:value});$('monitoring-config-status').textContent='';notify('Czas alarmu zapisany.');}catch(error){notify(error.message);}
});
$('rotation-preview').addEventListener('click',async()=>{
  const button=$('rotation-preview'),box=$('rotation-preview-result');button.disabled=true;
  try{
    const job=await api('/api/rotation/previews','POST',{});box.replaceChildren(element('p','Podgląd w kolejce.'));
    const poll=async()=>{
      try{
        const value=await api(`/api/rotation/previews/${job.id}`);
        if(value.status==='queued'||value.status==='running'){box.replaceChildren(element('p',value.status==='queued'?'Podgląd w kolejce.':'Skanowanie nagrań...'));setTimeout(poll,3000);return;}
        button.disabled=false;
        if(value.status!=='done'){box.replaceChildren(element('p',value.error||'Podgląd nie powiódł się.'));return;}
        const result=value.result;box.replaceChildren(element('p',`Do usunięcia: ${result.files_count} plików. Szacowane wolne miejsce: ${(result.before/1e9).toFixed(2)} do ${(result.after/1e9).toFixed(2)} GB.`));
        if(result.protected_count)box.append(element('p',`Chronione pliki: ${result.protected_count} (${(result.protected_bytes/1e9).toFixed(2)} GB). Nie zostaną usunięte.`));
        if(!result.reached_target)box.append(element('p','Nie osiągnięto zapasu - brak dostatecznej liczby plików możliwych do usunięcia.'));
        if(result.unknown_time_count)box.append(element('p',`Pominięto ${result.unknown_time_count} plików (${(result.unknown_time_bytes/1e9).toFixed(2)} GB) z nieistniejącym czasem lokalnym.`));
        if(result.files.length){const list=element('details');list.append(element('summary',result.truncated?'Pierwsze 500 plików':'Pliki do usunięcia'));for(const name of result.files)list.append(element('p',name));box.append(list);}
      }catch(error){button.disabled=false;notify(error.message);}
    };await poll();
  }catch(error){button.disabled=false;notify(error.message);}
});
async function uploadUpdateFile(kind,file){
  const response=await fetch('/api/update-uploads/'+kind,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/octet-stream','X-CSRF-Token':cookie('sunhill_csrf')},body:file});
  const value=await response.json();if(!response.ok)throw new Error(value.error||'Nie udało się przesłać pliku.');return value.id;
}
$('upgrade-refresh').addEventListener('click',async()=>{try{await refreshUpgradeStatus();}catch(error){notify(error.message);}});
$('upgrade-form').addEventListener('submit',async(event)=>{
  event.preventDefault();const form=event.target,button=form.querySelector('button[type="submit"]');
  const name=form.elements.package.value;if(!name)return;
  button.disabled=true;
  try{await api('/api/updates','POST',{package:name});watchUpgrade();await refreshUpgradeStatus();notify('Aktualizacja oczekuje na instalację.');}
  catch(error){notify(error.message);button.disabled=false;}
});
let syncItems=[],syncTimer=null,syncSeconds=0,syncStarted=0,syncBase=0,syncPlaying=false,syncDay='',syncGeneration=0,syncLoading=null;
function stopSync(){syncGeneration++;syncLoading=null;if(syncTimer)clearInterval(syncTimer);syncTimer=null;syncPlaying=false;for(const item of syncItems){item.active=null;item.video.pause();item.video.removeAttribute('src');}syncItems=[];$('sync-grid').replaceChildren();}
function openSync(){
  view('sync');$('sync-zone').textContent='Strefa kamer: '+me.timezone;$('sync-start').value=cameraDay()+'T12:00:00';
  const box=$('sync-cameras');box.replaceChildren();
  for(const camera of cameras){const label=element('label');const input=element('input');input.type='checkbox';input.value=String(camera.id);input.checked=true;label.append(input,document.createTextNode(camera.name));box.append(label);}
}
function syncClock(epoch){
  return new Intl.DateTimeFormat('pl-PL',{timeZone:me.timezone,dateStyle:'short',timeStyle:'medium'}).format(new Date(epoch*1000));
}
async function prepareSync(){
  stopSync();const value=$('sync-start').value;if(!value)throw new Error('Wybierz datę i czas.');
  const ids=Array.from($('sync-cameras').querySelectorAll('input:checked')).map(x=>Number(x.value));
  if(!ids.length)throw new Error('Wybierz co najmniej jedną kamerę.');
  const generation=syncGeneration,fold=$('sync-fold').value;
  const instant=await api('/api/time/resolve','POST',{local:value,fold:fold===''?null:Number(fold)});
  if(generation!==syncGeneration)return;
  const initial=Date.parse(instant.utc)/1000;if(!Number.isFinite(initial))throw new Error('Nieprawidłowy czas serwera.');
  const day=cameraDay(initial*1000),grid=$('sync-grid');
  const selected=ids.map(id=>cameras.find(c=>c.id===id)).filter(Boolean);
  const lists=await Promise.all(selected.map(camera=>archivePages(`/api/cameras/${camera.id}/recordings?date=${encodeURIComponent(day)}`,'recordings',()=>generation===syncGeneration)));
  if(generation!==syncGeneration)return;
  syncSeconds=initial;syncDay=day;
  for(let i=0;i<selected.length;i++){const camera=selected[i],list=lists[i].recordings;
    const box=element('article',null,'camera');const title=element('div',camera.name,'camera-heading');const video=element('video');video.controls=true;video.playsInline=true;video.muted=true;video.className='sync-video';const status=element('p','Gotowe','camera-actions');box.append(title,video,status);grid.append(box);
    syncItems.push({id:camera.id,video,status,records:list,active:null});
  }
  $('sync-clock').textContent=syncClock(syncSeconds);
}
async function loadSyncDay(day){
  if(syncLoading)return;const generation=syncGeneration,items=syncItems.slice();syncLoading=day;
  for(const item of items){item.active=null;item.video.pause();item.video.removeAttribute('src');item.status.textContent='Wczytywanie nagrań';}
  try{
    const lists=await Promise.all(items.map(item=>archivePages(`/api/cameras/${item.id}/recordings?date=${encodeURIComponent(day)}`,'recordings',()=>generation===syncGeneration)));
    if(generation!==syncGeneration)return;
    for(let i=0;i<items.length;i++)items[i].records=lists[i].recordings;
    syncDay=day;
  }catch(error){if(generation===syncGeneration){pauseSync();notify(error.message);}}
  finally{if(generation===syncGeneration)syncLoading=null;}
}
function tickSync(){
  if(!syncPlaying)return;
  syncSeconds=syncBase+(performance.now()-syncStarted)/1000;
  const day=cameraDay(syncSeconds*1000);$('sync-clock').textContent=syncClock(syncSeconds);
  if(day!==syncDay){loadSyncDay(day);return;}
  for(const item of syncItems){
    const record=item.records.find(r=>containsInstant(r,syncSeconds));
    if(!record||record.utc_second){if(item.active!==null){item.video.pause();item.video.removeAttribute('src');item.active=null;}item.status.textContent=record?'Niejednoznaczny czas po zmianie czasu':'Brak nagrania';continue;}
    const offset=Math.max(0,syncSeconds-Date.parse(record.utc_first)/1000);
    if(item.active!==record.id){item.active=record.id;item.video.src=`/api/recordings/${record.id}/file`;item.video.addEventListener('loadedmetadata',()=>{if(syncPlaying&&item.active===record.id&&syncItems.includes(item)){item.video.currentTime=offset;item.video.play().catch(()=>{});}},{once:true});}
    else if(item.video.readyState>=1){if(Math.abs(item.video.currentTime-offset)>1.5)item.video.currentTime=offset;if(item.video.paused)item.video.play().catch(()=>{});}
    item.status.textContent='Odtwarzanie';
  }
}
function pauseSync(){if(syncPlaying)syncSeconds=syncBase+(performance.now()-syncStarted)/1000;syncPlaying=false;if(syncTimer)clearInterval(syncTimer);syncTimer=null;for(const item of syncItems)item.video.pause();}
$('sync-load').addEventListener('click',async()=>{try{await prepareSync();notify('Widok przygotowany.');}catch(error){notify(error.message);}});
$('sync-play').addEventListener('click',()=>{if(syncPlaying)return;if(!syncItems.length){notify('Najpierw przygotuj widok.');return;}syncBase=syncSeconds;syncStarted=performance.now();syncPlaying=true;tickSync();syncTimer=setInterval(tickSync,500);});
$('sync-pause').addEventListener('click',pauseSync);
$('ha-form').addEventListener('submit',async(event)=>{event.preventDefault();try{
 const form=event.target;await api('/api/settings/home-assistant','PATCH',{url:form.elements.url.value,token:form.elements.token.value,enabled:form.elements.enabled.checked});form.elements.token.value='';notify('Ustawienia Home Assistant zapisane.');
}catch(error){notify(error.message);}});
$('storage-form').addEventListener('submit',async(event)=>{event.preventDefault();try{
  const value=formData(event.target);const minimum=Math.round(Number(value.minimum)*1e9),buffer=Math.round(Number(value.buffer)*1e9);
  if(!Number.isSafeInteger(minimum)||!Number.isSafeInteger(buffer)||minimum<0||buffer<0)throw new Error('Nieprawidłowe limity.');
  await api('/api/settings/storage','PATCH',{minimum_free:minimum,free_buffer:buffer});$('storage-limit-status').textContent='';notify('Limity miejsca zapisane.');
}catch(error){notify(error.message);}});
$('archive-form').addEventListener('submit',async(event)=>{event.preventDefault();
  if(!window.confirm('Przełączyć katalog? Poprzednie pliki pozostaną na starej ścieżce, a nagrywanie zostanie chwilowo wstrzymane.'))return;
  try{await api('/api/settings/storage/archive','POST',{archive:event.target.elements.archive.value,exports:event.target.elements.exports.value,...(event.target.elements.staging.value?{staging:event.target.elements.staging.value}:{})});$('storage-change-status').textContent='Zmiana katalogu oczekuje na przetworzenie.';notify('Zlecono zmianę katalogu.');}
  catch(error){notify(error.message);}
});
$('protect-range').addEventListener('click',async()=>{
  if(protectionSubmitting)return;
  const camera=activeCamera,generation=exportViewGeneration;protectionSubmitting=true;
  const value=formData($('export-form'));
  try{
    if(!value.start||!value.end)throw new Error('Wybierz początek i koniec zakresu.');
    const request={start_local:value.start,end_local:value.end,start_fold:value.start_fold===''?null:Number(value.start_fold),end_fold:value.end_fold===''?null:Number(value.end_fold),gaps:value.gaps};
    const result=await api(`/api/cameras/${camera.id}/export-protect`,'POST',request);
    if(generation!==exportViewGeneration||camera!==activeCamera)return;
    await loadArchive();if(generation===exportViewGeneration&&camera===activeCamera)notify(`Ochroną objęto pliki: ${result.files}. Nowo zabezpieczone: ${result.protected}.`);
  }catch(error){if(generation===exportViewGeneration&&camera===activeCamera)notify(error.message);}
  finally{if(generation===exportViewGeneration)protectionSubmitting=false;}
});
$('export-form').addEventListener('submit',async(event)=>{
  event.preventDefault();if(exportSubmitting)return;
  const camera=activeCamera,generation=exportViewGeneration;exportSubmitting=true;const value=formData(event.target);
  try{
    if(!value.start||!value.end)throw new Error('Wybierz zakres czasu.');
    const request={start_local:value.start,end_local:value.end,start_fold:value.start_fold===''?null:Number(value.start_fold),end_fold:value.end_fold===''?null:Number(value.end_fold),gaps:value.gaps};
    const preview=await api(`/api/cameras/${camera.id}/export-preview`,'POST',request);
    if(generation!==exportViewGeneration||camera!==activeCamera||$('archive-view').hidden)return;
    if(preview.gaps.length && !window.confirm(`W zaznaczonym czasie są ${preview.gaps.length} przerwy o łącznym czasie ${Math.round(preview.missing_seconds)} s. Czas wynikowego pliku: ${Math.round(preview.output_seconds)} s. Przygotować plik?`))return;
    const job=await api(`/api/cameras/${camera.id}/export-jobs`,'POST',request);
    if(generation!==exportViewGeneration||camera!==activeCamera){await refreshExports();return;}
    const box=$('export-result');box.replaceChildren(element('p','Eksport w kolejce.'));await refreshExports();
    if(generation!==exportViewGeneration||camera!==activeCamera)return;
    if(exportTimer!==null)clearInterval(exportTimer);let polling=false;
    const timer=setInterval(async()=>{
      if(polling)return;polling=true;
      try{const state=await api(`/api/export-jobs/${job.id}`);if(generation!==exportViewGeneration||camera!==activeCamera||exportTimer!==timer)return;
        const labels={queued:'W kolejce',running:'Przetwarzanie',done:'Gotowe',failed:'Błąd'};const progress=state.status==='running'?' - '+Math.round(Math.max(0,Math.min(1,state.progress))*100)+'%':'';box.replaceChildren(element('p','Status: '+(state.cancel_requested?'Anulowanie':state.cancelled?'Anulowano':labels[state.status]||state.status)+progress));
        if(state.status==='done'){clearInterval(timer);if(exportTimer===timer)exportTimer=null;refreshExports();const link=element('a','Pobierz gotowy MP4');link.href=`/api/export-jobs/${job.id}/file`;box.append(link);}
        if(state.status==='failed'){clearInterval(timer);if(exportTimer===timer)exportTimer=null;refreshExports();box.append(element('p',state.error||'Eksport nie powiódł się.'));}
      }catch(error){clearInterval(timer);if(exportTimer===timer){exportTimer=null;if(generation===exportViewGeneration&&camera===activeCamera)notify(error.message);}}
      finally{polling=false;}
    },3000);
    exportTimer=timer;
  }catch(error){if(generation===exportViewGeneration&&camera===activeCamera)notify(error.message);}
  finally{if(generation===exportViewGeneration)exportSubmitting=false;}
});
setInterval(async()=>{if(!me||document.hidden)return;try{const fresh=(await api('/api/cameras')).cameras;for(const camera of fresh){const card=document.querySelector(`.camera[data-camera-id="${camera.id}"]`);const badge=card&&card.querySelector('.health');if(badge)badge.textContent=cameraHealthText(camera);}}catch(error){notify(error.message);}},60000);
start();
