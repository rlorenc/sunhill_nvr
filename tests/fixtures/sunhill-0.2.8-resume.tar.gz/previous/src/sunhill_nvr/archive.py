"""Index finished camera recordings without changing their paths or contents."""
from __future__ import annotations
import math
import os
import sqlite3
import stat
import time
import contextlib
from dataclasses import dataclass
from datetime import timedelta,timezone
from pathlib import Path
from typing import Callable
from zoneinfo import ZoneInfo
from .rotation import list_recordings
from .timeline import utc_candidates

SCHEMA='''
CREATE TABLE IF NOT EXISTS recordings (
 id INTEGER PRIMARY KEY, relative_path TEXT NOT NULL UNIQUE, camera TEXT NOT NULL,
 local_time TEXT NOT NULL, utc_first TEXT, utc_second TEXT, duration REAL NOT NULL,
 file_size INTEGER NOT NULL, mtime_ns INTEGER NOT NULL, generation INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_recordings_camera_local ON recordings(camera,local_time);
CREATE INDEX IF NOT EXISTS idx_recordings_camera_utc_first ON recordings(camera,utc_first);
CREATE INDEX IF NOT EXISTS idx_recordings_camera_utc_second ON recordings(camera,utc_second);
CREATE INDEX IF NOT EXISTS idx_recordings_camera_mtime ON recordings(camera,mtime_ns DESC,id DESC);
CREATE INDEX IF NOT EXISTS idx_recordings_local_time ON recordings(local_time);
CREATE TABLE IF NOT EXISTS recording_identity (
 relative_path TEXT PRIMARY KEY REFERENCES recordings(relative_path) ON DELETE CASCADE,
 device TEXT NOT NULL, inode TEXT NOT NULL, ctime_ns TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS recording_stream_info (
 relative_path TEXT PRIMARY KEY REFERENCES recordings(relative_path) ON DELETE CASCADE,
 has_audio INTEGER NOT NULL CHECK(has_audio IN (0,1))
);
CREATE TABLE IF NOT EXISTS archive_scan_state (id INTEGER PRIMARY KEY CHECK(id=1), generation INTEGER NOT NULL);
INSERT OR IGNORE INTO archive_scan_state(id,generation) VALUES (1,0);
CREATE TABLE IF NOT EXISTS archive_recording_sequence (
 id INTEGER PRIMARY KEY CHECK(id=1), highwater INTEGER NOT NULL CHECK(highwater>=0)
);
INSERT OR IGNORE INTO archive_recording_sequence(id,highwater) SELECT 1,COALESCE(MAX(id),0) FROM recordings;
-- Keep the high-water mark even when rotation or a storage switch removes
-- the last indexed recording. Existing IDs and table layout remain intact.
CREATE TRIGGER IF NOT EXISTS archive_recording_sequence_insert AFTER INSERT ON recordings
BEGIN
 UPDATE archive_recording_sequence SET highwater=MAX(highwater,NEW.id) WHERE id=1;
END;
'''

def initialize(db: sqlite3.Connection) -> None:
    db.executescript(SCHEMA);db.commit()

@dataclass(frozen=True)
class ScanReport:
    accepted: int
    failed: int
    removed: int

def refresh(db: sqlite3.Connection, root: Path, timezone_name: str, *,
            inspect_duration: Callable[[Path], float], is_open: Callable[[Path], bool],
            mount_check: Callable[[], bool], min_age_seconds: int = 900,
            now: float | None = None, dates: set | None = None,
            on_verified: Callable[[Path,os.stat_result],None] | None = None,
            on_persist: Callable[[sqlite3.Connection],None] | None = None,
            commit_guard=None) -> ScanReport:
    """Refresh after a complete traversal. Unreadable files never trigger pruning.

    Mount identity and in-use checks must come from the supervising service. If any
    file cannot be inspected, old index entries are retained until the next scan.
    """
    if root.is_symlink() or not root.is_dir() or not mount_check():
        raise RuntimeError('archive mount unavailable')
    zone=ZoneInfo(timezone_name)
    now=time.time() if now is None else now
    if min_age_seconds < 0 or not math.isfinite(now):
        raise ValueError('invalid scan parameters')
    recordings=list_recordings(root,min_age_seconds=min_age_seconds,now=now,dates=dates,timezone_name=timezone_name)
    if dates is None:
        rows=db.execute('SELECT r.relative_path,r.file_size,r.mtime_ns,r.duration,i.device,i.inode,i.ctime_ns FROM recordings r LEFT JOIN recording_identity i ON i.relative_path=r.relative_path')
    else:
        first=min(dates);last=max(dates)
        rows=db.execute('SELECT r.relative_path,r.file_size,r.mtime_ns,r.duration,i.device,i.inode,i.ctime_ns FROM recordings r LEFT JOIN recording_identity i ON i.relative_path=r.relative_path WHERE r.local_time>=? AND r.local_time<?',
                        (first.isoformat(),(last+timedelta(days=1)).isoformat()))
    existing={r[0]:r[1:] for r in rows}
    items=[];failed=0
    for r in recordings:
        try:
            relative=str(r.path.relative_to(root))
            info=r.path.lstat()
            cached=existing.get(relative)
            unchanged=bool(cached and cached[0]==info.st_size and cached[1]==info.st_mtime_ns
                           and cached[3]==str(info.st_dev) and cached[4]==str(info.st_ino)
                           and cached[5]==str(info.st_ctime_ns))
            if not unchanged and is_open(r.path):
                continue
            duration=float(cached[2] if unchanged else inspect_duration(r.path))
            if not math.isfinite(duration) or duration <= 0 or duration > 86400:
                raise ValueError('invalid duration')
            # Ensure a file that changed during probing is not indexed yet.
            after=r.path.lstat()
            if (info.st_dev,info.st_ino,info.st_size,info.st_mtime_ns,info.st_ctime_ns)!=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns):
                raise RuntimeError('file changed')
            times=(r.utc_timestamp,) if r.utc_timestamp is not None else utc_candidates(r.timestamp,zone)
            # Offset-bearing names identify an instant even when the configured
            # viewing timezone has changed since the segment was recorded.
            local_time=r.utc_timestamp.astimezone(zone).replace(tzinfo=None) if r.utc_timestamp is not None else r.timestamp
            items.append((relative,r.path.relative_to(root).parts[0],
                          local_time.isoformat(), times[0].isoformat() if times else None,
                          times[1].isoformat() if len(times)>1 else None,duration,info.st_size,info.st_mtime_ns,
                          str(info.st_dev),str(info.st_ino),str(info.st_ctime_ns),not unchanged))
        except (OSError,RuntimeError,ValueError):
            failed+=1
    if not mount_check():
        raise RuntimeError('archive mount changed during scan')
    with (commit_guard() if commit_guard is not None else contextlib.nullcontext()):
        db.execute('BEGIN IMMEDIATE')
        try:
            if not mount_check():raise RuntimeError('archive mount changed during reconciliation')
            gen=db.execute('SELECT generation FROM archive_scan_state WHERE id=1').fetchone()[0]+1
            accepted=0
            highwater=db.execute('SELECT MAX(highwater,(SELECT COALESCE(MAX(id),0) FROM recordings)) FROM archive_recording_sequence WHERE id=1').fetchone()[0]
            for item in items:
                # The production worker holds a shared archive lock while this
                # transaction runs. Revalidate after acquiring it because a
                # rotator may have deleted or replaced a file during scanning.
                try:
                    verified_info=(root/item[0]).lstat()
                    if (not stat.S_ISREG(verified_info.st_mode) or verified_info.st_nlink!=1 or
                            (verified_info.st_size,verified_info.st_mtime_ns,str(verified_info.st_dev),str(verified_info.st_ino),str(verified_info.st_ctime_ns))!=item[6:11]):
                        raise ValueError('recording changed before index commit')
                except (OSError,ValueError):
                    failed+=1;continue
                # Never reuse a deleted recording's public numeric ID. A stale
                # browser link must fail, not play a different recording.
                existing_id=db.execute('SELECT id FROM recordings WHERE relative_path=?',(item[0],)).fetchone()
                if existing_id is None:
                    if highwater>=9_999_999_999_999:raise RuntimeError('recording identity limit reached')
                    highwater+=1
                rid=existing_id[0] if existing_id else highwater
                db.execute('''INSERT INTO recordings(id,relative_path,camera,local_time,utc_first,utc_second,duration,file_size,mtime_ns,generation)
                    VALUES (?,?,?,?,?,?,?,?,?,?) ON CONFLICT(relative_path) DO UPDATE SET camera=excluded.camera,
                    local_time=excluded.local_time,utc_first=excluded.utc_first,utc_second=excluded.utc_second,
                    duration=excluded.duration,file_size=excluded.file_size,mtime_ns=excluded.mtime_ns,generation=excluded.generation''',(rid,*item[:8],gen))
                db.execute('''INSERT INTO recording_identity(relative_path,device,inode,ctime_ns) VALUES (?,?,?,?)
                    ON CONFLICT(relative_path) DO UPDATE SET device=excluded.device,inode=excluded.inode,ctime_ns=excluded.ctime_ns''',(item[0],item[8],item[9],item[10]))
                if on_verified is not None and item[11]:on_verified(root/item[0],verified_info)
                accepted+=1
            if on_persist is not None:on_persist(db)
            removed=0
            # An entry absent from the current generation is removed only if the
            # exact recorded path is genuinely absent. Unreadable/open/recent files
            # remain indexed; file serving must independently revalidate every path.
            stale=db.execute('SELECT id,relative_path FROM recordings WHERE generation<>?',(gen,)).fetchall() if dates is None else ()
            for row_id,relative in stale:
                if not mount_check():
                    raise RuntimeError('archive mount changed during reconciliation')
                path=root / relative
                try:
                    path.lstat()
                except FileNotFoundError:
                    db.execute('DELETE FROM recording_identity WHERE relative_path=?',(relative,))
                    db.execute('DELETE FROM recording_stream_info WHERE relative_path=?',(relative,))
                    db.execute('DELETE FROM recordings WHERE id=?',(row_id,))
                    removed+=1
                except OSError:
                    continue
            db.execute('UPDATE archive_scan_state SET generation=? WHERE id=1',(gen,))
            if not mount_check():raise RuntimeError('archive mount changed during reconciliation')
            db.commit()
            return ScanReport(accepted,failed,removed)
        except BaseException:
            db.rollback();raise
